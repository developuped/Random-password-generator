# Definition of Success — Study Planner

**Критерії**
- Документи: README.md + MVP.md + stakeholders.md + success.md присутні в репозиторії.
- Функціонал: головний сценарій працює (додавання → перегляд → відзначення).
- Якість: немає критичних помилок при ручному тестуванні.
- Коміт: зрозуміле повідомлення коміту (наприклад, "Add Practical 1 docs: pitch, MVP, stakeholders").
